import React, { Component } from 'react';

export class RestaurantList extends Component {
  render() {
    return (
      <div>
        <h1>RestaurantList</h1>
      </div>
    );
  }
}

export default RestaurantList;
