import React, { Component } from 'react';

export class RestaurantSearch extends Component {
  render() {
    return (
      <div>
        <h1>RestaurantSearch</h1>
      </div>
    );
  }
}

export default RestaurantSearch;
