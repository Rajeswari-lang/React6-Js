import React, { Component } from 'react';

export class Restaurantupdate extends Component {
  render() {
    return (
      <div>
        <h1>Restaurantupdate</h1>
      </div>
    );
  }
}

export default Restaurantupdate;
