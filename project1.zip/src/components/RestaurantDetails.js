import React, { Component } from 'react';

export class RestaurantDetails extends Component {
  render() {
    return (
      <div>
        <h1>RestaurantDetails</h1>
      </div>
    );
  }
}

export default RestaurantDetails;
